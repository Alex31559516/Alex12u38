import os
os.system("clear")
print("32Bit not available ...")
