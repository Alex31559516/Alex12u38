![440312088_2775493195934952_561884511671557045_n](https://github.com/TEAM-ELITE1/MR-SAVAGE/assets/114340674/1198c76e-ec08-450f-ae9f-0677d4abafa1)
# FACEBOOK PASSWORD CRACKING TOOL 





# 📲 Installation ⟩
```
cd 
rm -rf MR-SAVAGE
git clone --depth=1 https://github.com/TEAM-ELITE1/MR-SAVAGE
cd MR-SAVAGE
chmod 777 XD
./XD
```
